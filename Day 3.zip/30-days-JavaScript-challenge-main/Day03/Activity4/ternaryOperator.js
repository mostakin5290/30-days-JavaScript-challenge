//Activity:4
//Task:6
let num = 2;
(num & 1)==0 ? console.log(`${num} is an even number.`) : console.log(`${num} is an odd number.`);;
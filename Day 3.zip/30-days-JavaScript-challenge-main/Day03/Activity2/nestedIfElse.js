//Activity:2
//Task:3
let n1 = 2, n2 = 30, n3 = 5;
if (n1 > n2) {
    if (n1 > n3) {
        console.log(`${n1} is the largest number`);
    }
    else {
        console.log(`${n3} is the largest number`);
    }
}
else {
    if (n2 > n3) {
        console.log(`${n2} is the largest number`);
    }
    else {
        console.log(`${n3} is the largest number`);
    }
}
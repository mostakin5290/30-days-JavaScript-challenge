//Activity:1
//Task:1
let num = 2;
if (num === 0) {
    console.log("The number is Zero.");
}
else if (num > 0) {
    console.log("The number is positive.");
}
else {
    console.log("The number is Negative.");
}

//Task:2
let age="18";
if(typeof age==='number' && age>=18){
    console.log("Congrats!!! you're eligible for voting.");
}
else{
    console.log("Sorry you don't eligible for voting.")
}
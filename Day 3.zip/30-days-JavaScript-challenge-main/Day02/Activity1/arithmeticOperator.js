//Activity-1:Arithmetic operators
let m, n;
m = 3;
n = 5;
//Task:1
console.log("Addition of m & n: " + (m + n));

//Task:2
console.log("Subtruction of m & n: " + (m - n));

//Task:3
console.log("Multiplication of m & n: " + (m * n));

//Task:4
console.log("Division of m & n: " + (m / n));

//Task:5
console.log("Reminder of m & n: " + (m % n));
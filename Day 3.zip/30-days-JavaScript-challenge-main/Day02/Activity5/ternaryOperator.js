//Activity 5: Ternary operator
//Task:14
let x = 2, y = 3;
x > y ? console.log("The value of x: " + x) : console.log("The value of y: " + y);
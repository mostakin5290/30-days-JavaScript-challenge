//Activity 3: Comprision Operators
let x = 2, y = 3;
//Task:8
console.log("x > y: " + (x > y));
console.log("x < y: " + (x < y));

//Task:9
//x = y = 1;
console.log("x >= y: " + (x >= y));
console.log("x <= y: " + (x <= y));

//Task:10
//y='2';
console.log("x == y: " + (x == y));
console.log("x === y: " + (x === y));
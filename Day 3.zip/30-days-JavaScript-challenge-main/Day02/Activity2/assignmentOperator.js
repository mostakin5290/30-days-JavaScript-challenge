//Activity 2:Assignment Operators
let x = 0;
//Task:6
x += 5;
console.log("Value of x: " + x);
//Task:7
x -= 2;
console.log("Value of x: " + x);
//Activity 4: Logical Operators
let x=true,y=false;

//Task:11
console.log("x && y: " + (x && y));

//Task:12
console.log("x || y: " + (x || y));

//Task:13
console.log("!x: " + (!x));
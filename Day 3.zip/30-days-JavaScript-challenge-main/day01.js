//Activity-1
//Task-1
var x = 1;
console.log("Value of x: " + x);
//Task-2
let y = "Asfar";
console.log("Value of y: " + y);

//Activity-2
//Task-3
const z = true;
console.log("Value of z: " + z);

//Activity-3
//Task-4
let a, b, c;
a = 3;
b = true;
c = "Java script";
let obj = {
    Name: "Asfar",
    "my age": 22,
    Greet: function () {
        console.log("Hi my name is " + this.Name)
    }
};
let arr = ["Mango", 2, 3.5];
console.log("Type of a: ", typeof (a));
console.log("Type of b: ", typeof (b));
console.log("Type of c: ", typeof (c));
console.log("Type of obj: ", typeof (obj));
console.log("Type of arr: ", typeof (arr));

//Activity-4
//Task-5
let m = 3;
console.log("Before update value of m: " + m);
m = 5;
console.log("After update value of m: " + m);

//Activity-5
//task-6
const c1 = 1;
c1 = 3; //Error: Assignment to constant variable...